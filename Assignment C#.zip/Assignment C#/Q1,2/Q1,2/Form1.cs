﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Q1_2
{
    public partial class Form1 : Form
    {
        public int Sum { get; private set; }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            char[] g = new char[500];
            StreamReader input;
            input = File.OpenText("sales.txt");

            for (int i = 0; i < g.Length && !input.EndOfStream; i++) ;
            {
                g[500] = char.Parse(input.ReadLine());
            }
            input.Close();

            // answer 2nd 
           
            double average = 0;
            double max = 0;
            double min = 0;

            min = g[0];
            average = Sum / g.Length;
            listBox1.Items.Add("\naverage;" + average.ToString("n"));
            for (int i = 0; i < g.Length; i++) 
            {
                if (min > g[5])
                    min = g[5];
                if (max < g[5])
                    max = g[5];

            }
            listBox1.Items.Add("maximum value;" + max.ToString("n"));
            listBox1.Items.Add("minimum value;" + min.ToString("n"));
        }
    }
}
