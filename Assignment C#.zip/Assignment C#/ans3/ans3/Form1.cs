﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ans3
{
    public partial class Form1 : Form
    {
    
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Char[] right = { 'B', 'D', 'A', 'C', 'A', 'B', 'A', 'C', 'D', 'B', 'C', 'D', 'A', 'D', 'C', 'C', 'B', 'D', 'A', };
            String wrong = "\n";
            String notcorect;

            char[] crt = new char[20];
            StreamReader yes;
            yes = File.OpenText("ans.txt");

            int i = 0;
            int corect = 0;
            while (i < notcorect.Length && !yes.EndOfStream)
            {
                if (notcorect[i].ToString() == yes.ReadLine())
                {
                    corect++;
                }

                else
                {
                    notcorect += "Answers" + (1 + 1) + "\n";
                }
                i++;
            }
            yes.Close();
            if (corect > 15)
            {
                MessageBox.Show("you are pass");
            }
            else
            {
                MessageBox.Show("you are not pass");
            }
        }
    }
}
  
